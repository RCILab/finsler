# Finsler Flow Matching — 논문과 코드

로봇의 속도 봉투는 비대칭입니다. 전진이 후진보다 빠르고, 옆걸음은 더 느립니다.
리만 계량은 $\|v\|_G=\|-v\|_G$라서 이 차이를 표현하지 못합니다.
이 연구는 봉투를 **Finsler 계량**으로 놓고($F(q,v)\neq F(q,-v)$, 전방 거리 = 최소 이동시간),
그 측지선을 flow matching의 conditional path로 써서 **비싼 시간최적 계획을 신경망 한 번의 적분으로 상각**합니다.

RSS 투고용입니다. 제목: *There and Back Are Not the Same: Finsler Flow Matching for Asymmetric Robot Planning*.

## 폴더

| | |
|---|---|
| [paper/](paper/) | 논문. `main.tex`(8쪽), `supplement.tex`(4쪽), 그림, 참고문헌, RSS 템플릿 원본 |
| [code/](code/) | 논문의 모든 표·그림·숫자를 만드는 코드. 라이브러리, 실험, 시뮬, 검사 |

먼저 읽을 것: [paper/main.pdf](paper/main.pdf) → [code/README.md](code/README.md)의 "논문 → 코드 대응표" → [code/notes/01_target_field_derivation.md](code/notes/01_target_field_derivation.md)(유도 기록).

## 논문 빌드

```powershell
cd 'C:\Users\ggory\Desktop\new manifold\finsler\paper'
pdflatex main; bibtex main; pdflatex main; pdflatex main
pdflatex supplement; bibtex supplement; pdflatex supplement; pdflatex supplement
```

TeX Live 2026에서 경고 없이 빌드됩니다. 본문은 6쪽에서 끝나고 7–8쪽이 참고문헌입니다(RSS 제한은 참고문헌 제외 8쪽).

## 코드 실행

```powershell
cd 'C:\Users\ggory\Desktop\new manifold\finsler\code'
python tests/run_tests.py            # 34개 수치 검사
python tests/run_tests_general.py    # 22개
python tests/run_tests_se2.py        # 17개
```

필요한 패키지: `numpy`, `scipy`, `torch`, `matplotlib`, 그리고 시뮬에 `mujoco`, `pyyaml`.
실험 스크립트와 결과의 대응은 [code/README.md](code/README.md)에 있습니다.
결과는 이미 `code/results/`와 `code/sim/results/`에 들어 있으므로, 표를 확인만 할 거라면 다시 돌릴 필요가 없습니다.

## 세 가지 기여

1. **비대칭 능력을 기하로.** 속도 봉투의 gauge 함수가 Finsler 계량이고, 그 전방 거리가 곧 최소 이동시간입니다. 계획 기하를 설계하는 게 아니라 **측정**합니다.
2. **비가역 기하 위의 flow matching.** 조건부 경로를 Finsler 측지선으로 두고, 목표장을 전방 거리에서 Legendre 변환으로 얻습니다. 비가역이라 두 가지가 달라지고 논문은 둘 다 짚습니다. 목표 방향은 거리의 음의 기울기가 아니고, 손실 가중은 표본 끝점에 의존하면 안 됩니다.
3. **봉투까지 상각.** 시작·목표뿐 아니라 **능력 봉투**에 대해서도 상각합니다. 조건부 장 하나가 처음 보는 봉투에도 같은 13–29 ms에 답하는 반면, 격자 solver는 계량이 바뀔 때마다 그래프를 새로 지어야 합니다.

## 지금 상태

끝난 것: 이론(목표장 유도, 손실 가중 remark), 평면·SE(2)·장애물 계획기, 미지 비대칭 강도 외삽,
롤아웃에서 봉투 학습, latency, 폐루프 외란, MuJoCo H1-2 실행.
SE(2) 최적성은 격자가 아니라 **정확한 측지선**으로 검증했습니다(Finsler 0.998, 대칭 1.064, 유클리드 1.212).

**남은 것 하나: Go2 실기입니다.**
논문에서 실기 문장은 이미 완료형으로 쓰여 있고 **빨간색 `\nd{...}`**로 감싸져 있습니다.
측정값이 나오면 숫자를 바꾸고 `\nd{}`만 벗기면 됩니다.
무엇을 어떻게 재야 하는지는 [paper/HARDWARE.md](paper/HARDWARE.md)에 빨간 문장별로 적어 두었습니다.
제출 전에 `grep -n "\\nd{" main.tex`가 아무것도 내지 않아야 합니다.
